/// <reference types="vite/client" />

declare module "*.png" {
  const value: string;
  return value;
}

declare module "*.jpg" {
  const value: string;
  return value;
}

declare module "*.jpeg" {
  const value: string;
  return value;
}

declare module "*.svg" {
  const value: string;
  return value;
}
