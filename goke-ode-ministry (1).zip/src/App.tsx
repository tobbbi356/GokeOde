/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, ArrowUp, Sparkles, AlertCircle } from 'lucide-react';

import Hero from './components/Hero';
import About from './components/About';
import MediaSection from './components/MediaSection';
import Conference from './components/Conference';
import ConnectHub from './components/ConnectHub';
import PrayerWall from './components/PrayerWall';

export default function App() {
  const [activeSection, setActiveSection] = useState('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);

  // Monitor scroll behavior for navigation highlighting and scroll-to-top button
  useEffect(() => {
    const handleScroll = () => {
      // Toggle scroll-to-top button
      if (window.scrollY > 500) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }

      // Highlight current section
      const sections = ['home', 'about', 'media', 'kcc', 'connect', 'prayer-wall'];
      const scrollPosition = window.scrollY + 250;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const top = element.offsetTop;
          const height = element.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const menuItems = [
    { label: 'Home', target: 'home' },
    { label: 'About', target: 'about' },
    { label: 'Media Deck', target: 'media' },
    { label: 'KCC 2026', target: 'kcc' },
    { label: 'Connect', target: 'connect' },
    { label: 'Prayer Board', target: 'prayer-wall' }
  ];

  return (
    <div id="app-root" className="min-h-screen bg-brand-obsidian text-slate-100 flex flex-col justify-between font-sans selection:bg-amber-500/30 selection:text-amber-300 relative">
      
      {/* Immersive Atmospheric Ambient Glow Highlights */}
      <div className="absolute top-[-5%] left-[-5%] w-[45%] h-[45%] bg-amber-955/20 bg-amber-500/5 rounded-full blur-[120px] pointer-events-none z-0"></div>
      <div className="absolute bottom-[10%] right-[-5%] w-[40%] h-[40%] bg-amber-950/5 rounded-full blur-[110px] pointer-events-none z-0"></div>
      
      {/* 2026 Live Banner Notification */}
      <div className="relative z-50 bg-gradient-to-r from-amber-950/50 via-brand-obsidian to-amber-950/50 border-b border-amber-500/10 py-2.5 text-center text-xs font-mono px-4 flex items-center justify-center space-x-2">
        <AlertCircle className="w-4 h-4 text-amber-400 animate-pulse" />
        <span className="text-slate-300">
          <strong className="text-amber-400 font-bold">KCC 2026 is LIVE in Abuja:</strong> Join 'ONE HEART, ONE VOICE' Thursday June 11 - Sunday June 14, 2026!
        </span>
        <button 
          id="banner-register-trigger"
          onClick={() => scrollToSection('kcc')}
          className="underline text-amber-300 font-bold hover:text-white transition cursor-pointer ml-1"
        >
          Confirm Reservation
        </button>
      </div>

      {/* Sticky Header Nav */}
      <header id="main-nav-bar" className="sticky top-0 w-full bg-brand-obsidian/70 backdrop-blur-xl border-b border-white/10 z-40">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 h-20 flex items-center justify-between">
          
          {/* Logo & Slogan alignment */}
          <button 
            id="nav-logo"
            onClick={() => scrollToSection('home')}
            className="flex flex-col items-start cursor-pointer group"
          >
            <span className="text-lg font-sans font-medium tracking-[0.25em] text-white group-hover:text-amber-400 transition duration-300">
              GOKE ODE
            </span>
            <span className="text-[8px] font-mono tracking-widest text-slate-500 uppercase group-hover:text-amber-200 transition duration-300">
              His Desire Ministry
            </span>
          </button>

          {/* Desktop Navigation links */}
          <nav id="desktop-links" className="hidden md:flex items-center space-x-8">
            {menuItems.map((item) => (
              <button
                id={`nav-link-${item.target}`}
                key={item.target}
                onClick={() => scrollToSection(item.target)}
                className={`text-[10px] uppercase font-mono tracking-widest transition duration-300 md:cursor-pointer relative py-2 ${
                  activeSection === item.target 
                    ? 'text-amber-400 font-bold' 
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {item.label}
                {activeSection === item.target && (
                  <motion.div 
                    layoutId="nav-line" 
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-amber-500 to-amber-200" 
                  />
                )}
              </button>
            ))}
          </nav>

          {/* Main CTA button */}
          <div className="hidden lg:flex items-center">
            <button
              id="cta-reserve-btn"
              onClick={() => scrollToSection('kcc')}
              className="h-10 inline-flex items-center space-x-2 px-5 bg-white/5 border border-white/10 hover:border-amber-500/30 hover:bg-white/10 rounded-full text-[10px] font-mono text-amber-400 hover:text-amber-300 tracking-widest transition cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin" />
              <span>RSVP PASS</span>
            </button>
          </div>

          {/* Mobile hamburger menu toggle */}
          <div className="md:hidden flex items-center">
            <button
              id="mobile-hamburger"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-slate-400 hover:text-white p-2 cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </header>

      {/* Mobile Menu Slide-out panel */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            key="mobile-nav-panel"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="md:hidden fixed top-24 left-0 right-0 w-full bg-brand-obsidian/95 backdrop-blur-2xl border-b border-white/10 z-35 overflow-hidden shadow-2xl"
          >
            <div className="px-6 py-8 space-y-4 flex flex-col items-stretch">
              {menuItems.map((item) => (
                <button
                  id={`mobile-link-${item.target}`}
                  key={item.target}
                  onClick={() => scrollToSection(item.target)}
                  className={`text-left text-xs uppercase font-mono tracking-widest py-3 px-4 rounded-xl transition duration-200 cursor-pointer ${
                    activeSection === item.target 
                      ? 'bg-white/5 text-amber-400 font-bold border-l-2 border-amber-500' 
                      : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {item.label}
                </button>
              ))}
              <div className="pt-4 border-t border-white/10">
                <button
                  id="mobile-logo-cta"
                  onClick={() => scrollToSection('kcc')}
                  className="w-full text-center h-11 inline-flex items-center justify-center space-x-2 bg-gradient-to-r from-amber-500 to-amber-300 text-black text-xs font-mono font-bold tracking-widest rounded-xl cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-black" />
                  <span>KCC 2026 TICKET</span>
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Primary Assembly Content */}
      <main className="flex-grow relative z-10">
        <Hero onScrollToSection={scrollToSection} />
        <About />
        <MediaSection />
        <Conference />
        <ConnectHub />
        <PrayerWall />
      </main>

      {/* Elegant footer with brand info and slogan */}
      <footer id="footer" className="bg-brand-obsidian border-t border-white/5 py-14 px-6 lg:px-8 text-slate-500 relative z-10">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
          
          <div className="text-center md:text-left space-y-2">
            <h4 className="text-sm font-sans font-medium tracking-[0.25em] text-white uppercase">
              GOKE ODE MINISTRIES
            </h4>
            <p className="text-xs text-slate-400 max-w-sm leading-relaxed font-light">
              Prophetic praise, structural intercessor, worship singer. Dedicated to establishing the true worshipers of the Father in Abuja and across the nations.
            </p>
          </div>

          <div className="flex flex-col items-center md:items-end space-y-2">
            <h4 className="text-xs font-mono font-medium text-amber-400 uppercase tracking-widest leading-none">
              HIS DESIRE MINISTRY
            </h4>
            <p className="text-[10px] text-slate-400 italic">
              "Raising and building true worshipers."
            </p>
            <div className="pt-2 text-[10px] font-mono text-slate-600">
              © 2026 Goke Ode Ministry. All Rights Reserved.
            </div>
          </div>

        </div>
      </footer>

      {/* Floating Scroll To Top trigger */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button
            id="scroll-to-top"
            onClick={() => scrollToSection('home')}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="fixed bottom-6 right-6 w-11 h-11 bg-gradient-to-tr from-amber-500 to-amber-200 text-black hover:scale-105 rounded-full flex items-center justify-center shadow-lg hover:shadow-amber-950/50 z-40 transition-transform cursor-pointer"
          >
            <ArrowUp className="w-5 h-5 stroke-[2.5]" />
          </motion.button>
        )}
      </AnimatePresence>

    </div>
  );
}
