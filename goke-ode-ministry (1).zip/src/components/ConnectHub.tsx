/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { Youtube, Instagram, Facebook, Twitter, Music, Disc, Compass, ExternalLink } from 'lucide-react';
import { SocialLink } from '../types';

export default function ConnectHub() {
  const links: SocialLink[] = [
    {
      id: 'youtube',
      name: 'YouTube Channel',
      url: 'https://www.youtube.com/@GokeOde',
      icon: 'youtube',
      color: 'hover:border-amber-500/50 hover:bg-amber-500/5 hover:text-amber-400 group',
      category: 'music'
    },
    {
      id: 'spotify',
      name: 'Spotify Store',
      url: 'https://open.spotify.com/artist/050h7Teb9xS8dG7iB9fXz9',
      icon: 'spotify',
      color: 'hover:border-amber-500/50 hover:bg-amber-500/5 hover:text-amber-400 group',
      category: 'music'
    },
    {
      id: 'apple',
      name: 'Apple Music',
      url: 'https://music.apple.com/us/artist/goke-ode/1329241551',
      icon: 'apple',
      color: 'hover:border-amber-500/50 hover:bg-amber-500/5 hover:text-amber-400 group',
      category: 'music'
    },
    {
      id: 'amazon',
      name: 'Amazon Music',
      url: 'https://music.amazon.com/artists/B07FF3H2GD/goke-ode',
      icon: 'amazon',
      color: 'hover:border-amber-500/50 hover:bg-amber-500/5 hover:text-amber-400 group',
      category: 'music'
    },
    {
      id: 'tiktok',
      name: 'TikTok Official',
      url: 'https://www.tiktok.com/@goke_ode',
      icon: 'tiktok',
      color: 'hover:border-amber-500/50 hover:bg-amber-500/5 hover:text-amber-400 group',
      category: 'social'
    },
    {
      id: 'instagram',
      name: 'Instagram Profile',
      url: 'https://www.instagram.com/goke_ode',
      icon: 'instagram',
      color: 'hover:border-amber-500/50 hover:bg-amber-500/5 hover:text-amber-400 group',
      category: 'social'
    },
    {
      id: 'facebook',
      name: 'Facebook Page',
      url: 'https://www.facebook.com/gokeode',
      icon: 'facebook',
      color: 'hover:border-amber-500/50 hover:bg-amber-500/5 hover:text-amber-400 group',
      category: 'social'
    },
    {
      id: 'twitter',
      name: 'Twitter Handle',
      url: 'https://twitter.com/goke_ode',
      icon: 'twitter',
      color: 'hover:border-amber-500/50 hover:bg-amber-500/5 hover:text-amber-400 group',
      category: 'social'
    }
  ];

  const getBrandIcon = (iconName: string) => {
    switch (iconName) {
      case 'youtube':
        return <Youtube className="w-6 h-6 transition-transform duration-300 group-hover:scale-110" />;
      case 'instagram':
        return <Instagram className="w-6 h-6 transition-transform duration-300 group-hover:scale-110" />;
      case 'facebook':
        return <Facebook className="w-6 h-6 transition-transform duration-300 group-hover:scale-110" />;
      case 'twitter':
        return <Twitter className="w-6 h-6 transition-transform duration-300 group-hover:scale-110" />;
      case 'spotify':
        return <Compass className="w-6 h-6 text-amber-400 transition-transform duration-300 group-hover:scale-110" />;
      case 'apple':
        return <Music className="w-6 h-6 text-amber-400 transition-transform duration-300 group-hover:scale-110" />;
      case 'amazon':
        return <Disc className="w-6 h-6 text-amber-400 transition-transform duration-300 group-hover:scale-110" />;
      default:
        return <ExternalLink className="w-6 h-6 transition-transform duration-300 group-hover:scale-110" />;
    }
  };

  const getBrandSlogan = (id: string) => {
    switch (id) {
      case 'youtube': return 'Watch conference logs & clips';
      case 'spotify': return 'Listen to studio albums';
      case 'apple': return 'Stream high-fidelity singles';
      case 'amazon': return 'Purchase spiritual tracks';
      case 'tiktok': return 'Get daily 365 righteous bites';
      case 'instagram': return 'Follow live posts & reels';
      case 'facebook': return 'Join our praise community';
      case 'twitter': return 'Get prophetic declarations';
      default: return 'Connect with the ministry';
    }
  };

  return (
    <section id="connect" className="relative py-28 bg-transparent overflow-hidden border-t border-white/5">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-amber-955/15 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-20 space-y-4">
          <h2 className="text-xs font-mono tracking-[0.25em] text-amber-400 uppercase">
            ESTABLISH CONNECTION
          </h2>
          <h3 className="text-4xl sm:text-5xl font-serif italic text-white tracking-tight">
            Follow His Desire Online
          </h3>
          <p className="text-slate-400 font-light leading-relaxed">
            Select standard gateways to stay anchored to Pastor Goke Ode's social media streams, audio channels, and daily wisdom boards.
          </p>
        </div>

        {/* Bento Grid layout */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {links.map((link, i) => (
            <motion.a
              key={link.id}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
              className={`bg-white/5 backdrop-blur-xl border border-white/10 p-6 rounded-3xl flex flex-col justify-between aspect-square md:aspect-auto md:min-h-[175px] transition-all duration-300 text-slate-400 hover:text-white cursor-pointer ${link.color}`}
            >
              <div className="flex justify-between items-start">
                <div className="bg-white/5 p-3.5 rounded-2xl border border-white/10">
                  {link.id === 'tiktok' ? (
                    <span className="font-mono text-lg font-bold tracking-tight text-amber-400 group-hover:scale-110 block">tK</span>
                  ) : (
                    getBrandIcon(link.icon)
                  )}
                </div>
                <ExternalLink className="w-4 h-4 text-slate-600 group-hover:text-current transition duration-200" />
              </div>

              <div className="mt-6 space-y-1 text-left">
                <h4 className="font-semibold text-white group-hover:text-current transition">
                  {link.name}
                </h4>
                <p className="text-xs text-slate-550 text-slate-500 group-hover:text-slate-300 transition font-light">
                  {getBrandSlogan(link.id)}
                </p>
              </div>
            </motion.a>
          ))}
        </div>

        {/* Bottom banner note */}
        <div className="mt-16 text-center text-[10px] font-mono text-slate-500 flex items-center justify-center space-x-2 uppercase tracking-widest font-semibold">
          <span>GOKE ODE OFFICIAL</span>
          <span className="text-slate-700 font-normal">•</span>
          <span className="text-amber-400 font-semibold">Raising and building true worshipers</span>
        </div>

      </div>
    </section>
  );
}
