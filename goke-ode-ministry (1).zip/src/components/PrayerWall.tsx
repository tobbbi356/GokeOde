/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Landmark, Send, Check, Bookmark, Sparkles, User } from 'lucide-react';

interface Note {
  id: string;
  name: string;
  content: string;
  type: 'testimony' | 'prayer';
  date: string;
  likes: number;
}

export default function PrayerWall() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [formName, setFormName] = useState('');
  const [formContent, setFormContent] = useState('');
  const [formType, setFormType] = useState<'testimony' | 'prayer'>('testimony');
  const [showDoneAlert, setShowDoneAlert] = useState(false);

  const initialNotes: Note[] = [
    {
      id: 'pre-1',
      name: 'Pastor Samuel, Abuja',
      content: 'Under the ministration for Overture 3.0, the atmosphere in my home shifted completely. Absolute deliverance!',
      type: 'testimony',
      date: 'May 28, 2026',
      likes: 42
    },
    {
      id: 'pre-2',
      name: 'Sister Jennifer, Lagos',
      content: 'Praying for structural revival in our church leaders during the upcoming Kingdom Culture Conference 2026. May they receive authentic power!',
      type: 'prayer',
      date: 'May 29, 2026',
      likes: 21
    },
    {
      id: 'pre-3',
      name: 'Brother David, USA',
      content: '"The Joy Factor" literally quantum-leaped my day! I was battling heavy thoughts until those short audio booster minutes revolutionized my outlook.',
      type: 'testimony',
      date: 'May 30, 2026',
      likes: 35
    },
    {
      id: 'pre-4',
      name: 'Ebenezer, Port Harcourt',
      content: 'Please pray for my mother\'s heart health, we believe in the healing rains of God of His Desire to wash over her this June.',
      type: 'prayer',
      date: 'May 30, 2026',
      likes: 19
    }
  ];

  useEffect(() => {
    const saved = localStorage.getItem('goke_ode_prayer_notes');
    if (saved) {
      setNotes(JSON.parse(saved));
    } else {
      localStorage.setItem('goke_ode_prayer_notes', JSON.stringify(initialNotes));
      setNotes(initialNotes);
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName || !formContent) return;

    const newNote: Note = {
      id: 'note-' + Date.now(),
      name: formName,
      content: formContent,
      type: formType,
      date: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      }),
      likes: 1
    };

    const updated = [newNote, ...notes];
    setNotes(updated);
    localStorage.setItem('goke_ode_prayer_notes', JSON.stringify(updated));

    setFormName('');
    setFormContent('');
    setShowDoneAlert(true);
    setTimeout(() => {
      setShowDoneAlert(false);
    }, 3000);
  };

  const handleLike = (id: string) => {
    const actionKey = 'liked_note_' + id;
    if (localStorage.getItem(actionKey)) return; // Disallow double voting on same session

    const updated = notes.map((note) => {
      if (note.id === id) {
        return { ...note, likes: note.likes + 1 };
      }
      return note;
    });

    setNotes(updated);
    localStorage.setItem('goke_ode_prayer_notes', JSON.stringify(updated));
    localStorage.setItem(actionKey, 'true');
  };

  return (
    <section id="prayer-wall" className="relative py-28 bg-transparent border-t border-white/5 overflow-hidden">
      <div className="absolute top-0 right-1/10 w-96 h-96 bg-amber-955/15 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        
        {/* Header Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start mb-20">
          
          {/* Header left text details */}
          <div className="lg:col-span-7 space-y-4 text-left">
            <div className="inline-flex items-center space-x-2 bg-white/5 border border-white/10 px-3 py-1.5 rounded-full">
              <Landmark className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-[10px] font-mono text-amber-300 uppercase tracking-widest font-semibold">
                prophetic altar & testimonies
              </span>
            </div>
            <h3 className="text-4xl sm:text-5xl font-serif italic text-white tracking-tight">
              Aroma of Intercessions & Victory
            </h3>
            <p className="text-slate-400 font-light leading-relaxed">
              A sacred platform to log what God has done under our streams or submit your focused prayer petitions. We agree with you in Spirit and in truth.
            </p>
          </div>

          <div className="lg:col-span-5 w-full flex lg:justify-end">
            <span className="text-[10px] uppercase font-mono tracking-widest text-amber-400 bg-white/5 border border-white/10 px-4 py-2 rounded-full font-semibold">
              ACTIVE COMMUNION • DAILY AGREEMENT
            </span>
          </div>

        </div>

        {/* Content Board: split layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Form write (Left/Column 4) */}
          <div className="lg:col-span-4 bg-white/5 backdrop-blur-xl border border-white/10 rounded-[32px] p-6 space-y-6">
            <div className="space-y-1">
              <h4 className="font-serif italic text-white text-xl">Write on Altar board</h4>
              <p className="text-xs text-slate-400 font-light">Post a public petition or share what God has accomplished.</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[9px] font-mono text-slate-400 uppercase tracking-widest font-semibold">Your Name & City</label>
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    id="altar-name"
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="Brother Paul, Mpape"
                    className="w-full h-11 bg-white/5 border border-white/10 focus:border-amber-500/50 rounded-xl text-xs text-white pl-10 pr-3 outline-none transition duration-300"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[9px] font-mono text-slate-400 uppercase tracking-widest block font-semibold">Submission Type</label>
                <div className="grid grid-cols-2 gap-2 text-center">
                  <button
                    id="altar-type-testimony"
                    type="button"
                    onClick={() => setFormType('testimony')}
                    className={`h-10 px-3 rounded-xl border text-[10px] font-mono uppercase tracking-wider font-semibold transition cursor-pointer duration-300 ${
                      formType === 'testimony'
                        ? 'bg-amber-500/10 border-amber-500 text-amber-400'
                        : 'bg-white/5 border-white/10 text-slate-400 hover:border-white/20'
                    }`}
                  >
                    Share Testimony
                  </button>
                  <button
                    id="altar-type-prayer"
                    type="button"
                    onClick={() => setFormType('prayer')}
                    className={`h-10 px-3 rounded-xl border text-[10px] font-mono uppercase tracking-wider font-semibold transition cursor-pointer duration-300 ${
                      formType === 'prayer'
                        ? 'bg-amber-500/10 border-amber-500 text-amber-400'
                        : 'bg-white/5 border-white/10 text-slate-400 hover:border-white/20'
                    }`}
                  >
                    Prayer Request
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-mono text-slate-400 uppercase tracking-widest block font-semibold">Message</label>
                <textarea
                  id="altar-msg"
                  required
                  rows={4}
                  value={formContent}
                  onChange={(e) => setFormContent(e.target.value)}
                  placeholder="Tell us what God has accomplished or outline your request..."
                  className="w-full bg-white/5 border border-white/10 focus:border-amber-500/50 rounded-xl p-4 text-xs text-white outline-none resize-none transition duration-350 font-light"
                />
              </div>

              <button
                id="altar-submit-btn"
                type="submit"
                className="w-full h-11 inline-flex items-center justify-center space-x-2 bg-gradient-to-tr from-amber-500 to-amber-200 text-black text-xs font-semibold uppercase tracking-widest rounded-full md:cursor-pointer transition duration-300 hover:scale-101"
              >
                <span>Write to Board</span>
                <Send className="w-3.5 h-3.5 text-black stroke-[3]" />
              </button>
            </form>

            {/* Submitting state Done indicator */}
            <AnimatePresence>
              {showDoneAlert && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="bg-amber-500/10 border border-amber-500/20 p-3 rounded-xl flex items-center space-x-2"
                >
                  <Check className="w-4 h-4 text-amber-400 flex-shrink-0" />
                  <span className="text-[11px] text-amber-350 font-medium">Placed securely on the board. We are in agreement!</span>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Wall of cards (Right/Column 8) */}
          <div className="lg:col-span-8 space-y-6">
            <div className="flex justify-between items-center text-[10px] font-mono text-slate-500 uppercase tracking-widest font-semibold">
              <span>Recent communion board ({notes.length})</span>
              <span className="text-amber-400 flex items-center space-x-1 font-semibold">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Prophetic Agreements</span>
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <AnimatePresence mode="popLayout">
                {notes.map((note) => {
                  const isTestimony = note.type === 'testimony';
                  return (
                    <motion.div
                      key={note.id}
                      layout
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      transition={{ duration: 0.4 }}
                      className="p-6 rounded-[32px] border flex flex-col justify-between space-y-5 transition-all duration-300 bg-white/5 border-white/10 hover:border-amber-500/20"
                    >
                      <div className="space-y-3">
                        <div className="flex justify-between items-center text-[9px] font-mono font-semibold">
                          <span className={`${isTestimony ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' : 'bg-red-550/10 text-red-400 border border-red-550/20'} uppercase tracking-widest font-bold`}>
                            {note.type}
                          </span>
                          <span className="text-slate-500 font-mono text-[9px]">{note.date}</span>
                        </div>
                        <p className="text-xs text-slate-300 leading-relaxed italic font-light font-sans">
                          "{note.content}"
                        </p>
                      </div>

                      <div className="pt-3.5 border-t border-white/5 flex items-center justify-between">
                        <span className="text-[10px] font-mono text-slate-500 font-semibold">{note.name}</span>
                        <button
                          id={`like-altar-${note.id}`}
                          onClick={() => handleLike(note.id)}
                          className="inline-flex items-center space-x-1.5 text-[10px] font-mono text-slate-450 hover:text-amber-400 transition cursor-pointer"
                        >
                          <Heart className="w-3.5 h-3.5 text-amber-500 fill-current" />
                          <span>{note.likes} Agree</span>
                        </button>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
