/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { ShieldCheck, Heart, Users, Star } from 'lucide-react';
import profileImg from '../assets/images/goke_profile_1780140335539.png';
import logoImg from '../assets/images/his_desire_logo_1780140355257.png';

export default function About() {
  return (
    <section id="about" className="relative py-28 bg-transparent overflow-hidden">
      {/* Decorative ambient blurred spots */}
      <div className="absolute top-1/2 left-0 -translate-y-1/2 w-80 h-80 bg-amber-955/15 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-0 right-0 w-64 h-64 bg-amber-900/5 rounded-full blur-2xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        
        {/* Header Block */}
        <div className="text-center max-w-3xl mx-auto mb-20 space-y-4">
          <h2 className="text-xs font-mono tracking-[0.25em] text-amber-400 uppercase">
            MEET THE WORSHIP LEADER
          </h2>
          <h3 className="text-4xl sm:text-5xl font-serif italic text-white tracking-tight">
            Goke Ode
          </h3>
          <p className="text-slate-400 font-light leading-relaxed">
            A voice crying out in the wilderness, establishing the glory of God through spiritual keys, prophetic songs of revival, and deep-seated devotion.
          </p>
        </div>

        {/* Content Columns */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Column A: Goke Portrait and Message */}
          <motion.div 
            className="lg:col-span-6 space-y-8"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8 }}
          >
            {/* Portrait Card */}
            <div className="relative max-w-md mx-auto lg:mx-0 aspect-[4/5] rounded-3xl overflow-hidden group shadow-2xl border border-white/10 bg-white/5">
              <img 
                src={profileImg} 
                alt="Goke Ode Portrait" 
                className="w-full h-full object-cover grayscale-30 contrast-105 group-hover:scale-102 transition duration-750"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-obsidian via-transparent to-transparent opacity-95" />
              
              {/* Overlay Slogan */}
              <div className="absolute bottom-8 left-8 right-8">
                <div className="flex items-center space-x-2 text-amber-400 mb-2">
                  <Star className="w-4 h-4 fill-current text-amber-400" />
                  <span className="text-[10px] font-mono tracking-widest uppercase font-semibold">Minister's Charge</span>
                </div>
                <p className="text-lg font-serif italic text-slate-100 leading-snug">
                  "Worship is not a performance; it is our life-breath offered back to the Father in absolute surrender."
                </p>
              </div>
            </div>
          </motion.div>

          {/* Column B: Logo emblem & His Desire slogan */}
          <motion.div 
            className="lg:col-span-6 space-y-8"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, delay: 0.15 }}
          >
            {/* Ministry Brand Board */}
            <div id="about-emblem" className="bg-white/5 backdrop-blur-xl p-8 rounded-3xl border border-white/10 shadow-lg space-y-6 flex flex-col md:flex-row gap-6 items-center">
              <div className="w-32 h-32 md:w-36 md:h-36 flex-shrink-0 bg-brand-obsidian rounded-2xl overflow-hidden border border-white/10 shadow-inner">
                <img 
                  src={logoImg} 
                  alt="His Desire Ministry Crest" 
                  className="w-full h-full object-cover grayscale brightness-95"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="flex-1 text-center md:text-left space-y-2">
                <h4 className="text-[10px] font-mono text-amber-400 uppercase tracking-widest font-semibold">
                  MINISTRY EMBLEM
                </h4>
                <h3 className="text-2xl font-serif text-white italic">
                  His Desire Ministries
                </h3>
                <p className="text-xs font-mono text-amber-200/90 tracking-wide font-medium">
                  "Raising and building true worshipers."
                </p>
                <p className="text-xs text-slate-400 font-light leading-relaxed">
                  Leading spirits back to the throne through focused intercession, persistent praise, and structural devotion.
                </p>
              </div>
            </div>

            {/* Core Values / Details Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-white/5 backdrop-blur-md p-6 rounded-3xl border border-white/10 space-y-3 hover:border-amber-500/20 transition-colors duration-300">
                <div className="w-10 h-10 bg-amber-500/10 rounded-xl flex items-center justify-center border border-amber-500/20">
                  <ShieldCheck className="w-5 h-5 text-amber-400" />
                </div>
                <h4 className="font-semibold text-white text-sm">Spiritual Anchors</h4>
                <p className="text-xs text-slate-400 font-light leading-relaxed">Grounded in Biblical truth, sound teaching, and Holy Spirit impartation.</p>
              </div>

              <div className="bg-white/5 backdrop-blur-md p-6 rounded-3xl border border-white/10 space-y-3 hover:border-amber-500/20 transition-colors duration-300">
                <div className="w-10 h-10 bg-amber-500/10 rounded-xl flex items-center justify-center border border-amber-500/20">
                  <Heart className="w-5 h-5 text-amber-400" />
                </div>
                <h4 className="font-semibold text-white text-sm">Genuine Heart</h4>
                <p className="text-xs text-slate-400 font-light leading-relaxed">Removing theatrical showmanship to secure an original connection with God.</p>
              </div>

              <div className="bg-white/5 backdrop-blur-md p-6 rounded-3xl border border-white/10 space-y-3 hover:border-amber-500/20 transition-colors duration-300 col-span-1 sm:col-span-2">
                <div className="flex items-center space-x-3 mb-1">
                  <div className="w-10 h-10 bg-amber-500/10 rounded-xl flex items-center justify-center border border-amber-500/20">
                    <Users className="w-5 h-5 text-amber-400" />
                  </div>
                  <h4 className="font-semibold text-white text-sm">Community Building</h4>
                </div>
                <p className="text-xs text-slate-400 font-light leading-relaxed">Empowering emerging vocalists and instrumental leaders through Kingdom Culture Conferences (KCC) and year-round workshops.</p>
              </div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
