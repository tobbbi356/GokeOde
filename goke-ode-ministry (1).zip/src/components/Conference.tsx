/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, MapPin, Sparkles, Users, User, Mail, Phone, ArrowRight, Download, Ticket, CheckCircle } from 'lucide-react';
import kccBanner from '../assets/images/kcc_conference_banner_1780140373080.png';

interface Attendee {
  name: string;
  email: string;
  phone: string;
  type: 'in-person' | 'online';
  ticketId: string;
}

export default function Conference() {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });
  const [registeredAttendee, setRegisteredAttendee] = useState<Attendee | null>(null);
  
  // Registration state
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regType, setRegType] = useState<'in-person' | 'online'>('in-person');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Load existing RSVP
  useEffect(() => {
    const saved = localStorage.getItem('kcc_2026_rsvp');
    if (saved) {
      setRegisteredAttendee(JSON.parse(saved));
    }
  }, []);

  // Compute countdown timer (Target: June 11, 2026, 18:00 UTC)
  useEffect(() => {
    const targetDate = new Date('2026-06-11T18:00:00Z').getTime();

    const updateTimer = () => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
      }

      const d = Math.floor(difference / (1000 * 60 * 60 * 24));
      const h = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const m = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const s = Math.floor((difference % (1000 * 60)) / 1000);

      setTimeLeft({ days: d, hours: h, minutes: m, seconds: s });
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName || !regEmail || !regPhone) return;

    setIsSubmitting(true);

    setTimeout(() => {
      const ticketId = 'KCC26-' + Math.floor(100000 + Math.random() * 900000);
      const attendee: Attendee = {
        name: regName,
        email: regEmail,
        phone: regPhone,
        type: regType,
        ticketId
      };

      localStorage.setItem('kcc_2026_rsvp', JSON.stringify(attendee));
      setRegisteredAttendee(attendee);
      setIsSubmitting(false);
    }, 1200);
  };

  const handleCancelRegistration = () => {
    if (confirm('Are you sure you want to cancel your registration?')) {
      localStorage.removeItem('kcc_2026_rsvp');
      setRegisteredAttendee(null);
      setRegName('');
      setRegEmail('');
      setRegPhone('');
    }
  };

  const speakers = [
    { name: 'Dr. Moses Fagbemi', role: 'Keynote Speaker' },
    { name: 'Jennifer Agboli', role: 'Guest Worship Leader' },
    { name: 'Pst. Goke Ode', role: 'Host & Worship Leader' },
    { name: 'Moses Akoh', role: 'Guest Minister' },
    { name: 'E Daniels', role: 'Vocalist & Guest' },
    { name: 'Tade Sax', role: 'Instrumentalist' },
    { name: 'Tee Worship', role: 'Guest Leader' },
    { name: 'Osita Peter', role: 'Gospel Artist' },
    { name: 'Tope Sax', role: 'Instrumentalist' }
  ];

  return (
    <section id="kcc" className="relative py-28 bg-transparent overflow-hidden border-t border-white/5">
      {/* Background vector highlights */}
      <div className="absolute top-0 left-1/4 w-full h-1/2 bg-amber-955/15 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-full h-1/2 bg-amber-900/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        
        {/* Title Group */}
        <div className="text-center max-w-3xl mx-auto mb-20 space-y-4">
          <div className="inline-flex items-center space-x-2 bg-white/5 border border-white/10 px-4 py-1.5 rounded-full">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span className="text-[10px] font-mono text-amber-300 uppercase tracking-widest font-semibold">
              UPCOMING MAJOR CONVOCATION 2026
            </span>
          </div>
          <h2 className="text-5xl sm:text-6.5xl md:text-7xl font-serif italic text-white tracking-tight leading-none uppercase">
            ONE HEART, ONE VOICE
          </h2>
          <h3 className="text-xs font-mono text-amber-400 uppercase tracking-widest">
            Kingdom Culture Conference (KCC) 2026
          </h3>
          <p className="text-slate-400 font-light leading-relaxed">
            A dynamic convergence of worship, word, and apostolic impartations designed to revolutionize lives and raise an army of genuine worshipers.
          </p>
        </div>

        {/* Banner + Event Info Overview */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch mb-24">
          
          {/* Background image & details card (Left/Column 7) */}
          <div className="lg:col-span-7 flex flex-col justify-between p-8 sm:p-12 rounded-[40px] relative overflow-hidden bg-white/5 border border-white/10 shadow-2xl min-h-[480px]">
            {/* Poster background aspect */}
            <div className="absolute inset-0 z-0">
              <img 
                src={kccBanner} 
                alt="KCC 2026 background" 
                className="w-full h-full object-cover brightness-[25%] contrast-110 saturate-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-obsidian via-brand-obsidian/60 to-transparent" />
            </div>

            {/* Top Tag */}
            <div className="relative z-10 self-start">
              <span className="bg-amber-500 text-black text-[9px] font-mono font-bold tracking-widest uppercase px-3 py-1 rounded-full">
                Live & In-Person Mpape
              </span>
            </div>

            {/* Core Info */}
            <div className="relative z-10 space-y-8 mt-20">
              <div className="space-y-4">
                <div className="flex items-center space-x-3 text-slate-300">
                  <Calendar className="w-5 h-5 text-amber-400 flex-shrink-0" />
                  <span className="text-xs font-mono uppercase tracking-widest font-semibold text-slate-200">
                    Thursday 11th - Sunday 14th June 2026
                  </span>
                </div>
                <div className="flex items-start space-x-3 text-slate-300">
                  <MapPin className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                  <span className="text-sm leading-relaxed max-w-sm font-light text-slate-300">
                    Hope Alive Christian Centre, Hope Alive Avenue, Opp. Zenith Bank, Mpape, Abuja, Nigeria.
                  </span>
                </div>
                <div className="flex items-center space-x-3 text-slate-300">
                  <Users className="w-5 h-5 text-amber-400 flex-shrink-0" />
                  <span className="text-xs font-mono uppercase tracking-widest font-semibold text-slate-200">
                    Special Feature: KCC Mass Choir Revival
                  </span>
                </div>
              </div>

              {/* Countdown Board */}
              <div className="bg-[#08080a]/80 backdrop-blur-xl p-6 rounded-3xl border border-white/10 shadow-md">
                <h4 className="text-[10px] font-mono text-amber-400 uppercase tracking-widest text-center mb-4 font-semibold">
                  CONFERENCE COUNTDOWN
                </h4>
                <div className="grid grid-cols-4 gap-3 text-center">
                  <div className="bg-white/5 p-3 rounded-2xl border border-white/10">
                    <span className="block text-2xl sm:text-3xl font-sans font-semibold text-white">{timeLeft.days}</span>
                    <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider font-semibold">Days</span>
                  </div>
                  <div className="bg-white/5 p-3 rounded-2xl border border-white/10">
                    <span className="block text-2xl sm:text-3xl font-sans font-semibold text-white">{timeLeft.hours}</span>
                    <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider font-semibold">Hours</span>
                  </div>
                  <div className="bg-white/5 p-3 rounded-2xl border border-white/10">
                    <span className="block text-2xl sm:text-3xl font-sans font-semibold text-white">{timeLeft.minutes}</span>
                    <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider font-semibold">Mins</span>
                  </div>
                  <div className="bg-white/5 p-3 rounded-2xl border border-white/10">
                    <span className="block text-2xl sm:text-3xl font-sans font-bold text-amber-400">{timeLeft.seconds}</span>
                    <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider font-semibold">Secs</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive registration form or Ticket generator (Right/Column 5) */}
          <div className="lg:col-span-5 bg-white/5 backdrop-blur-xl border border-white/10 hover:border-amber-500/15 transition-all duration-300 shadow-2xl rounded-[40px] p-8 flex flex-col justify-center">
            <AnimatePresence mode="wait">
              {!registeredAttendee ? (
                <motion.div
                  key="registration-form"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  <div className="space-y-1">
                    <h3 className="text-2xl font-serif italic text-white text-left leading-tight">
                      Secure Your Seat (RSVP)
                    </h3>
                    <p className="text-xs text-slate-400 font-light">
                      Register to attend. Free access to in-person spaces and high-definition video feeds.
                    </p>
                  </div>

                  <form onSubmit={handleRegister} className="space-y-4">
                    <div className="space-y-1.5">
                      <label className="text-[9px] font-mono text-slate-400 uppercase tracking-widest font-semibold">Full Name</label>
                      <div className="relative">
                        <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                        <input
                          id="kcc-reg-name"
                          type="text"
                          required
                           value={regName}
                          onChange={(e) => setRegName(e.target.value)}
                          placeholder="Dr. Faith Adebayo"
                          className="w-full h-12 bg-white/5 border border-white/10 focus:border-amber-500/50 rounded-xl text-sm text-white pl-11 pr-4 outline-none transition duration-300"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[9px] font-mono text-slate-400 uppercase tracking-widest font-semibold">Email Address</label>
                      <div className="relative">
                        <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                        <input
                          id="kcc-reg-email"
                          type="email"
                          required
                          value={regEmail}
                          onChange={(e) => setRegEmail(e.target.value)}
                          placeholder="faith@gmail.com"
                          className="w-full h-12 bg-white/5 border border-white/10 focus:border-amber-500/50 rounded-xl text-sm text-white pl-11 pr-4 outline-none transition duration-300"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[9px] font-mono text-slate-400 uppercase tracking-widest font-semibold">Phone Number</label>
                      <div className="relative">
                        <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                        <input
                          id="kcc-reg-phone"
                          type="tel"
                          required
                          value={regPhone}
                          onChange={(e) => setRegPhone(e.target.value)}
                          placeholder="+234 803 123 4567"
                          className="w-full h-12 bg-white/5 border border-white/10 focus:border-amber-500/50 rounded-xl text-sm text-white pl-11 pr-4 outline-none transition duration-300"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[9px] font-mono text-slate-400 uppercase tracking-widest block font-semibold">Attendance Mode</label>
                      <div className="grid grid-cols-2 gap-3">
                        <button
                          id="kcc-mode-inperson"
                          type="button"
                          onClick={() => setRegType('in-person')}
                          className={`h-11 rounded-xl border text-[10px] font-mono uppercase tracking-wider font-semibold transition duration-300 md:cursor-pointer ${
                            regType === 'in-person'
                              ? 'bg-amber-500/10 border-amber-500 text-amber-400'
                              : 'bg-white/5 border-white/10 hover:border-white/20 text-slate-400'
                          }`}
                        >
                          Abuja In-Person
                        </button>
                        <button
                          id="kcc-mode-online"
                          type="button"
                          onClick={() => setRegType('online')}
                          className={`h-11 rounded-xl border text-[10px] font-mono uppercase tracking-wider font-semibold transition duration-300 md:cursor-pointer ${
                            regType === 'online'
                              ? 'bg-amber-500/10 border-amber-500 text-amber-400'
                              : 'bg-white/5 border-white/10 hover:border-white/20 text-slate-400'
                          }`}
                        >
                          HD Live Stream
                        </button>
                      </div>
                    </div>

                    <button
                      id="kcc-submit-btn"
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full h-12 inline-flex items-center justify-center space-x-2 bg-gradient-to-tr from-amber-500 to-amber-200 text-black font-semibold text-xs uppercase tracking-widest rounded-full md:cursor-pointer hover:scale-101 shadow-lg hover:shadow-amber-500/10 transition duration-300 disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <span>Validating Ticket...</span>
                      ) : (
                        <>
                          <span>Register For KCC 2026</span>
                          <ArrowRight className="w-4 h-4 text-black stroke-[3]" />
                        </>
                      )}
                    </button>
                  </form>
                </motion.div>
              ) : (
                <motion.div
                  key="ticket-display"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="space-y-6 text-center"
                >
                  <div className="w-12 h-12 bg-amber-500/10 border border-amber-500/35 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle className="w-6 h-6 text-amber-400" />
                  </div>

                  <div className="space-y-1">
                    <h3 className="text-2xl font-serif text-white italic">Seat Confirmed!</h3>
                    <p className="text-xs text-slate-400 font-light">
                      Your access pass for Kingdom Culture Conference 2026 is active.
                    </p>
                  </div>

                  {/* Aesthetic Digital Ticket representation */}
                  <div className="bg-[#08080a]/80 border border-white/10 rounded-3xl p-6 relative overflow-hidden text-left shadow-xl backdrop-blur-xl">
                    {/* Glowing side decorations */}
                    <div className="absolute top-1/2 -left-3 w-6 h-6 bg-[#08080a] border border-white/10 rounded-full -translate-y-1/2" />
                    <div className="absolute top-1/2 -right-3 w-6 h-6 bg-[#08080a] border border-white/10 rounded-full -translate-y-1/2" />
                    
                    <div className="border-b border-dashed border-white/10 pb-4 mb-4 flex justify-between items-center">
                      <div>
                        <h4 className="text-[9px] font-mono text-amber-400 uppercase tracking-widest font-semibold">KCC 2026 PASS</h4>
                        <p className="text-md font-serif italic text-white leading-tight">ONE HEART, ONE VOICE</p>
                      </div>
                      <Ticket className="w-8 h-8 text-amber-500/30" />
                    </div>

                    <div className="space-y-3">
                      <div>
                        <span className="text-[8px] font-mono text-slate-500 block uppercase tracking-wider font-semibold">Attendee</span>
                        <span className="text-sm font-sans text-white font-semibold">{registeredAttendee.name}</span>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <span className="text-[8px] font-mono text-slate-500 block uppercase tracking-wider font-semibold">Access Mode</span>
                          <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20">
                            {registeredAttendee.type === 'in-person' ? 'Abuja Seat' : 'Online Stream'}
                          </span>
                        </div>
                        <div>
                          <span className="text-[8px] font-mono text-slate-500 block uppercase tracking-wider font-semibold">Ticket Number</span>
                          <span className="text-xs font-mono text-white font-semibold">{registeredAttendee.ticketId}</span>
                        </div>
                      </div>

                      <div className="pt-3 border-t border-white/10 text-[9px] text-slate-400 font-mono text-center flex justify-between items-center">
                        <span>JUNE 11 - 14, 2026</span>
                        <span className="text-amber-400 font-semibold">6:00 PM GMT+1 Daily</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-center gap-3">
                    <button
                      id="kcc-cancel-btn"
                      onClick={handleCancelRegistration}
                      className="text-[10px] font-mono text-slate-500 hover:text-amber-400 transition cursor-pointer uppercase tracking-widest"
                    >
                      Cancel / Reset RSVP
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

        </div>

        {/* Featured Speakers Banner / Scrollable Grid */}
        <div className="space-y-6">
          <div className="flex flex-col md:flex-row items-center justify-between border-b border-white/10 pb-4">
            <h3 className="text-xl font-serif text-white italic">
              Anointed Guest Ministers & Instruments
            </h3>
            <span className="text-[9px] font-mono text-slate-500 mt-1 md:mt-0 uppercase tracking-widest font-semibold">
              WORD | WORSHIP | IMPARTATIONS
            </span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {speakers.map((speaker, index) => (
              <div 
                key={index} 
                className="bg-white/5 border border-white/10 p-5 rounded-3xl text-center hover:border-amber-500/20 hover:bg-white/10 transition duration-300"
              >
                <div className="w-10 h-10 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto mb-3 border border-amber-500/20">
                  <span className="text-amber-400 font-bold text-xs">{speaker.name.charAt(0)}</span>
                </div>
                <h4 className="font-semibold text-white text-xs tracking-tight">{speaker.name}</h4>
                <p className="text-[9px] text-slate-400 mt-1 uppercase font-mono tracking-widest">{speaker.role}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Historic KCC Notice */}
        <div className="mt-20 bg-white/5 p-6 rounded-3xl border border-white/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <div>
            <h4 className="font-semibold text-white text-sm">Looking for previous convocations?</h4>
            <p className="text-xs text-slate-400 mt-1 font-light">Review live recordings and testimonies from Kingdom Culture Conference 2024.</p>
          </div>
          <button 
            onClick={() => {
              const el = document.getElementById('media');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className="text-xs font-mono text-amber-400 hover:text-amber-300 flex items-center space-x-1 cursor-pointer font-semibold uppercase tracking-widest"
          >
            <span>Watch KCC 2024 Stream</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </section>
  );
}
