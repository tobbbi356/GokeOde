/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { Play, Flame, ArrowDown, Music } from 'lucide-react';
import worshipBanner from '../assets/images/goke_worship_banner_1780140310952.png';
import gokeProfile from '../assets/images/goke_profile_1780140335539.png';

interface HeroProps {
  onScrollToSection: (id: string) => void;
}

export default function Hero({ onScrollToSection }: HeroProps) {
  return (
    <section id="home" className="relative min-h-screen bg-transparent flex flex-col justify-center overflow-hidden pt-20">
      {/* Decorative ambient blobs */}
      <div className="absolute top-1/4 left-1/10 w-96 h-96 bg-amber-955/10 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/10 w-96 h-96 bg-amber-900/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto w-full px-6 lg:px-8 py-12 md:py-20 z-10 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        {/* Left column: Text Information */}
        <motion.div 
          className="lg:col-span-7 space-y-8 flex flex-col justify-center text-center lg:text-left"
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
        >
          <div className="inline-flex items-center space-x-2 bg-white/5 border border-white/10 px-4 py-2 rounded-full self-center lg:self-start w-fit">
            <Flame className="w-4 h-4 text-amber-400 animate-pulse" />
            <span className="text-[10px] font-mono text-amber-300 uppercase tracking-widest font-bold">
              LATEST RELEASE OUT NOW
            </span>
          </div>

          <div className="space-y-4">
            <h2 className="text-xs font-mono tracking-[0.3em] text-slate-400 uppercase">
              HIS DESIRE MINISTRY
            </h2>
            <h1 className="text-6xl sm:text-7xl md:text-8xl font-serif italic text-white tracking-tight leading-none">
              RAIN
              <span className="block mt-3 text-xl sm:text-2xl md:text-3xl font-sans font-light tracking-[0.25em] uppercase text-amber-500">
                The Sound of Revival
              </span>
            </h1>
          </div>

          <p className="text-slate-400 text-lg max-w-xl mx-auto lg:mx-0 leading-relaxed font-light">
            Leading a generation back to the heart of the Father through sound, spirit, and the word. Led by <strong className="text-white">Goke Ode</strong>, ministering authentic prophetic praise, structural intercession, and live revivals across Abuja.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
            <button
               id="hero-play-btn"
              onClick={() => onScrollToSection('media')}
              className="w-full sm:w-auto h-12 inline-flex items-center justify-center space-x-2 bg-gradient-to-tr from-amber-500 to-amber-200 text-black font-semibold uppercase tracking-widest px-8 rounded-full shadow-lg hover:shadow-amber-500/20 hover:scale-103 transition duration-300 md:cursor-pointer text-xs"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Listen Now</span>
            </button>
            <button
              id="hero-kcc-btn"
              onClick={() => onScrollToSection('kcc')}
              className="w-full sm:w-auto h-12 inline-flex items-center justify-center space-x-2 bg-white/5 border border-white/10 hover:bg-white/10 hover:border-amber-500/35 text-amber-400 uppercase tracking-widest px-8 rounded-full transition duration-300 md:cursor-pointer text-xs font-semibold"
            >
              <Music className="w-4 h-4 text-amber-400 animate-pulse" />
              <span>KCC 2026 Summit</span>
            </button>
          </div>

          <div className="flex items-center justify-center lg:justify-start space-x-6 pt-4 text-xs font-mono text-slate-500">
            <div>
              <span className="text-white block font-bold text-lg">10M+</span>
              <span>Global Streams</span>
            </div>
            <div className="w-px h-8 bg-white/10" />
            <div>
              <span className="text-white block font-bold text-lg">365+</span>
              <span>Daily Devotional</span>
            </div>
            <div className="w-px h-8 bg-white/10" />
            <div>
              <span className="text-white block font-bold text-lg">15+</span>
              <span>Years Ministering</span>
            </div>
          </div>
        </motion.div>

        {/* Right column: Image Frame with Neon Frame */}
        <motion.div 
          className="lg:col-span-5 relative flex justify-center items-center"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease: 'easeOut', delay: 0.2 }}
        >
          {/* Neon border lines */}
          <div className="absolute top-0 right-0 w-full h-full max-w-sm border-r-3 border-t-3 border-amber-500/40 rounded-tr-[40px] -mr-3 -mt-3 blur-xs pointer-events-none" />
          <div className="absolute top-0 right-0 w-full h-full max-w-sm border-r border-t border-amber-400/50 rounded-tr-[40px] -mr-3 -mt-3 pointer-events-none z-10" />
          
          <div className="absolute bottom-0 left-0 w-40 h-40 border-l border-b border-amber-500/25 rounded-bl-[40px] -ml-3 -mb-3 pointer-events-none" />

          {/* Core Art Poster */}
          <div id="hero-artwork" className="relative group w-full max-w-sm aspect-square bg-[#08080a] rounded-[40px] overflow-hidden shadow-2xl border border-white/10">
            <img 
              src={gokeProfile} 
              alt="Pastor Goke Ode" 
              className="w-full h-full object-cover object-top brightness-[100%] group-hover:scale-103 transition-all duration-700"
              referrerPolicy="no-referrer"
            />
            {/* Dark overlay gradients */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-transparent opacity-95" />
            
            {/* Info label on image */}
            <div className="absolute bottom-6 left-6 right-6">
              <span className="text-[10px] font-mono text-amber-400 tracking-widest block mb-1">
                PASTOR GOKE ODE • LEAD MINISTER
              </span>
              <h3 className="text-xl font-bold text-white tracking-tight">
                Raising & Building True Worshipers
              </h3>
              <p className="text-xs text-slate-400 font-light">Founder & Apostle, His Desire Ministries</p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Floating indicators */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center space-y-1">
        <span className="text-[10px] font-mono tracking-widest text-slate-500 uppercase">
          Explore Ministry
        </span>
        <motion.button 
          onClick={() => onScrollToSection('about')}
          className="text-slate-400 hover:text-white transition duration-300 md:cursor-pointer"
          animate={{ y: [0, 5, 0] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
        >
          <ArrowDown className="w-4 h-4" />
        </motion.button>
      </div>
    </section>
  );
}
