/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Pause, Youtube, Music, Radio, Volume2, Sparkles, ChevronRight, Share2, Heart } from 'lucide-react';
import { MediaItem } from '../types';

export default function MediaSection() {
  const [activeTab, setActiveTab] = useState<'all' | 'live' | 'single' | 'devotional'>('all');
  const [currentPlaying, setCurrentPlaying] = useState<MediaItem | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackTime, setPlaybackTime] = useState(0);
  const [timerInterval, setTimerInterval] = useState<NodeJS.Timeout | null>(null);

  const mediaCatalog: MediaItem[] = [
    // Live Conferences (KCC 2025)
    {
      id: 'kcc25-feast-live',
      title: 'KCC 2025, "THE FEAST" - WATCH LIVE',
      subtitle: 'Kingdom Culture Conference 2025',
      description: 'The ultimate final compilation stream. Deep intercession and high praise.',
      youtubeId: 'watch?v=GokeOdeKCC25Feast',
      url: 'https://www.youtube.com/@GokeOde',
      type: 'live',
      tags: ['KCC 2025', 'The Feast', 'Watch Live']
    },
    {
      id: 'kcc25-feast-d4',
      title: 'THE FEAST - KINGDOM CULTURE CONFERENCE 2025 (Day 4)',
      subtitle: 'Final Day - Impartations & Anointing Session',
      description: 'Crowning glory of KCC 2025 with apostolic declarations and worship.',
      youtubeId: 'watch?v=GokeOdeFeastDay4',
      url: 'https://www.youtube.com/@GokeOde',
      type: 'live',
      tags: ['KCC 2025', 'Day 4', 'Impartations']
    },
    {
      id: 'kcc25-outpouring-d3',
      title: 'KCC 2025, "THE OUTPOURING" - DAY 3',
      subtitle: 'The Outpouring Revival Night',
      description: 'A special prophetic service resulting in spontaneous worship sounds.',
      youtubeId: 'watch?v=GokeOdeOutpouringDay3',
      url: 'https://www.youtube.com/@GokeOde',
      type: 'live',
      tags: ['KCC 2025', 'The Outpouring', 'Day 3']
    },
    {
      id: 'kcc25-feast-d3',
      title: 'THE FEAST - KINGDOM CULTURE CONFERENCE 2025 (Day 3)',
      subtitle: 'Prophetic Encounters & Word session',
      description: 'Diving deep into the scriptures and establishing structural worship.',
      youtubeId: 'watch?v=GokeOdeFeastDay3',
      url: 'https://www.youtube.com/@GokeOde',
      type: 'live',
      tags: ['KCC 2025', 'Day 3', 'Word']
    },
    {
      id: 'kcc25-feast-d2',
      title: 'KCC 2025, "THE FEAST" - DAY 2',
      subtitle: 'Glory Encounter Session',
      description: 'Fervent prayer and heavy spiritual presence in Christ Jesus.',
      youtubeId: 'watch?v=GokeOdeFeastDay2',
      url: 'https://www.youtube.com/@GokeOde',
      type: 'live',
      tags: ['KCC 2025', 'Day 2', 'Worship']
    },
    {
      id: 'kcc25-feast-d1',
      title: 'KCC 2025, "THE FEAST" - DAY 1',
      subtitle: 'Opening Convocation & Welcoming Charge',
      description: 'Setting alignment for the conference. The feast is served.',
      youtubeId: 'watch?v=GokeOdeFeastDay1',
      url: 'https://www.youtube.com/@GokeOde',
      type: 'live',
      tags: ['KCC 2025', 'Day 1', 'Opening']
    },

    // Singles & Worship Recordings
    {
      id: 'rain-revival',
      title: 'RAIN - THE SOUND OF REVIVAL LIVE',
      subtitle: 'Official Revival Anthem',
      description: 'Goke Ode\'s highly acclaimed live worship single carrying the seal "His Desire".',
      url: 'https://open.spotify.com/artist/GokeOde',
      type: 'single',
      tags: ['Official Live', 'Rain', 'Revival Sound']
    },
    {
      id: 'kingdom-celebration',
      title: 'Kingdom Celebration Live',
      subtitle: 'Live Praise Explosion',
      description: 'Spontaneous high-energy worship and victory songs recorded in Abuja.',
      url: 'https://open.spotify.com/artist/GokeOde',
      type: 'single',
      tags: ['Praise', 'Abuja Live']
    },
    {
      id: 'overture-lift',
      title: 'Overture 3.0 + Lift Up Your Heads',
      subtitle: 'Goke Ode | His Desire | Kingdom Celebration',
      description: 'A masterpiece orchestra overture shifting into standard prophetic declaration.',
      youtubeId: 'watch?v=GokeOdeOverture3',
      url: 'https://www.youtube.com/watch?v=GokeOdeOverture3',
      type: 'single',
      tags: ['YouTube', 'His Desire', 'Overture']
    },
    {
      id: 'holy-jennifer',
      title: 'Holy | Goke Ode featuring Jennifer Agboli',
      subtitle: 'His Desire | Kingdom Celebration',
      description: 'A beautiful, sacred song of adoration and purity featuring heavy vocals.',
      youtubeId: 'watch?v=GokeOdeHoly',
      url: 'https://www.youtube.com/watch?v=GokeOdeHoly',
      type: 'single',
      tags: ['Holy', 'Duet', 'Worship']
    },

    // Devotionals & Reflections
    {
      id: 'joy-factor',
      title: 'The Joy Factor: Turbocharge your day',
      subtitle: 'Daily Prophetic Booster',
      description: 'Give your 24 hours a quantum leap in a few minutes, completely revolutionizing your life with the power of joy.',
      url: 'https://www.tiktok.com/@goke_ode',
      type: 'devotional',
      tags: ['Prophetic Booster', 'TikTok', 'Quantum Leap']
    },
    {
      id: 'righteous-devotional',
      title: '365 Days of the Righteous: YouTube',
      subtitle: 'Daily Spiritual Devotional Series',
      description: 'A magnificent year-round study tracking the paths of righteousness.',
      youtubeId: 'watch?v=GokeOde365Days',
      url: 'https://www.youtube.com/@GokeOde',
      type: 'devotional',
      tags: ['365 Days', 'YouTube Series', 'Daily Study']
    },
    {
      id: 'righteous-tiktok',
      title: 'TikTok - 365 Days of the Righteous',
      subtitle: 'Short Form Devotionals',
      description: 'Inspirational daily seeds of wisdom suited for mobile viewers.',
      url: 'https://www.tiktok.com/@goke_ode',
      type: 'devotional',
      tags: ['TikTok Shorts', 'Daily Wisdom']
    },

    // KCC 2024
    {
      id: 'kcc24-main',
      title: 'Kingdom Culture Conference 2024',
      subtitle: 'Annual Convocation Archives',
      description: 'Archived collections, messages, and spiritual highlights from 2024.',
      url: 'https://www.youtube.com/@GokeOde',
      type: 'live',
      tags: ['KCC 2024', 'Archives']
    },
    {
      id: 'kcc24-d1',
      title: 'Kingdom Culture Conference 2024 (Day 1) Livestream',
      subtitle: 'Day 1 Welcoming Keynote',
      description: 'The monumental opening night that paved the way for subsequent revivals.',
      youtubeId: 'watch?v=GokeOdeKCC24Day1',
      url: 'https://www.youtube.com/@GokeOde',
      type: 'live',
      tags: ['KCC 2024', 'Day 1', 'Livestream']
    }
  ];

  const handlePlayToggle = (item: MediaItem) => {
    if (currentPlaying?.id === item.id) {
      if (isPlaying) {
        clearInterval(timerInterval as NodeJS.Timeout);
        setIsPlaying(false);
      } else {
        setIsPlaying(true);
        triggerPlaybackTimer();
      }
    } else {
      // Start a new track
      if (timerInterval) clearInterval(timerInterval);
      setPlaybackTime(0);
      setCurrentPlaying(item);
      setIsPlaying(true);
      triggerPlaybackTimer();
    }
  };

  const triggerPlaybackTimer = () => {
    const interval = setInterval(() => {
      setPlaybackTime((prev) => {
        if (prev >= 210) {
          clearInterval(interval);
          setIsPlaying(false);
          return 0;
        }
        return prev + 1;
      });
    }, 1000);
    setTimerInterval(interval);
  };

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remaining = secs % 60;
    return `${mins}:${remaining < 10 ? '0' : ''}${remaining}`;
  };

  const filteredMedia = activeTab === 'all' 
    ? mediaCatalog 
    : mediaCatalog.filter(item => item.type === activeTab);

  return (
    <section id="media" className="relative py-28 bg-transparent border-t border-white/5 overflow-hidden">
      {/* Decorative radial gradients */}
      <div className="absolute top-1/4 right-0 w-96 h-96 bg-amber-955/15 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 left-0 w-96 h-96 bg-amber-900/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-16 gap-6">
          <div className="space-y-3 max-w-xl">
            <h2 className="text-xs font-mono tracking-[0.25em] text-amber-400 uppercase">
              MINISTRY DISCOGRAPHY & ARCHIVES
            </h2>
            <h3 className="text-4xl sm:text-5xl font-serif italic text-white tracking-tight">
              Anointed Sounds & Media
            </h3>
            <p className="text-slate-400 text-sm font-light">
              Stream spiritual resources, previous conferences, worship singles, and quick-charging devotionals directly into your device.
            </p>
          </div>

          {/* Stream Tags */}
          <div className="flex flex-wrap gap-2 bg-white/5 p-1.5 rounded-full border border-white/10 backdrop-blur-md">
            <button
              id="tab-all"
              onClick={() => { setActiveTab('all'); }}
              className={`px-5 py-2.5 text-[10px] font-mono uppercase tracking-widest rounded-full transition duration-300 md:cursor-pointer ${
                activeTab === 'all' ? 'bg-gradient-to-tr from-amber-500 to-amber-200 text-black font-semibold' : 'text-slate-400 hover:text-white'
              }`}
            >
              All Library
            </button>
            <button
              id="tab-live"
              onClick={() => { setActiveTab('live'); }}
              className={`px-5 py-2.5 text-[10px] font-mono uppercase tracking-widest rounded-full transition duration-300 md:cursor-pointer ${
                activeTab === 'live' ? 'bg-gradient-to-tr from-amber-500 to-amber-200 text-black font-semibold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Conferences
            </button>
            <button
              id="tab-single"
              onClick={() => { setActiveTab('single'); }}
              className={`px-5 py-2.5 text-[10px] font-mono uppercase tracking-widest rounded-full transition duration-300 md:cursor-pointer ${
                activeTab === 'single' ? 'bg-gradient-to-tr from-amber-500 to-amber-200 text-black font-semibold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Singles & Audio
            </button>
            <button
              id="tab-devotional"
              onClick={() => { setActiveTab('devotional'); }}
              className={`px-5 py-2.5 text-[10px] font-mono uppercase tracking-widest rounded-full transition duration-300 md:cursor-pointer ${
                activeTab === 'devotional' ? 'bg-gradient-to-tr from-amber-500 to-amber-200 text-black font-semibold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Devotionals
            </button>
          </div>
        </div>

        {/* Media Grid Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence mode="popLayout">
            {filteredMedia.map((item, index) => {
              const isSelected = currentPlaying?.id === item.id;
              const isMediaArtActive = isSelected && isPlaying;
              
              return (
                <motion.div
                  key={item.id}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.4, delay: index * 0.05 }}
                  className={`bg-white/5 backdrop-blur-xl hover:bg-white/10 rounded-3xl p-6 border transition duration-300 flex flex-col justify-between group ${
                    isSelected ? 'border-amber-500/60 shadow-lg shadow-amber-950/20' : 'border-white/10 hover:border-amber-500/20'
                  }`}
                >
                  <div className="space-y-4">
                    {/* Upper Line with icon and labels */}
                    <div className="flex justify-between items-center">
                      <span className={`text-[9px] font-mono font-bold tracking-widest px-2.5 py-0.5 rounded-full uppercase ${
                        item.type === 'live' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                        item.type === 'single' ? 'bg-amber-500/10 text-amber-350 border border-amber-500/20' :
                        'bg-white/10 text-slate-350 border border-white/10'
                      }`}>
                        {item.type}
                      </span>
                      
                      <div className="flex space-x-1.5">
                        {item.youtubeId ? (
                          <a 
                            href={item.url} 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="w-7 h-7 bg-white/5 border border-white/10 rounded-full flex items-center justify-center text-slate-400 hover:text-amber-400 hover:border-amber-500/50 transition cursor-pointer"
                          >
                            <Youtube className="w-3.5 h-3.5" />
                          </a>
                        ) : (
                          <a 
                            href={item.url} 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="w-7 h-7 bg-white/5 border border-white/10 rounded-full flex items-center justify-center text-slate-400 hover:text-amber-400 hover:border-amber-500/50 transition cursor-pointer"
                          >
                            <Music className="w-3.5 h-3.5" />
                          </a>
                        )}
                      </div>
                    </div>
 
                    {/* Title Text */}
                    <div className="space-y-1">
                      <h4 className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">
                        {item.subtitle || 'Official Ministry resource'}
                      </h4>
                      <h3 className="text-lg font-serif italic text-slate-100 group-hover:text-amber-400 leading-snug line-clamp-2 transition-colors duration-300">
                        {item.title}
                      </h3>
                      <p className="text-xs text-slate-400 mt-2 line-clamp-3 leading-relaxed font-light">
                        {item.description}
                      </p>
                    </div>
                  </div>

                  {/* Actions Bar */}
                  <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between">
                    <div className="flex flex-wrap gap-1">
                      {item.tags.slice(0, 2).map((tag, tIdx) => (
                        <span key={tIdx} className="text-[9px] font-mono text-slate-500 uppercase tracking-widest bg-white/5 border border-white/10 px-2 py-0.5 rounded-md">
                          {tag}
                        </span>
                      ))}
                    </div>

                    <div className="flex items-center space-x-2">
                      {/* Play action simulated trigger */}
                      {item.type === 'single' || item.type === 'devotional' ? (
                        <button
                          id={`play-ctr-${item.id}`}
                          onClick={() => handlePlayToggle(item)}
                          className={`w-9 h-9 rounded-full flex items-center justify-center transition cursor-pointer ${
                            isMediaArtActive 
                              ? 'bg-gradient-to-tr from-amber-500 to-amber-200 text-black animate-pulse'
                              : 'bg-white/5 border border-white/10 text-slate-350 hover:bg-white/10 hover:text-white'
                          }`}
                        >
                          {isMediaArtActive ? <Pause className="w-4 h-4 fill-current text-black" /> : <Play className="w-4 h-4 fill-current pl-0.5" />}
                        </button>
                      ) : (
                        <a 
                          id={`link-${item.id}`}
                          href={item.url} 
                          target="_blank" 
                          rel="noopener noreferrer" 
                          className="text-xs font-mono text-amber-400 hover:text-amber-300 inline-flex items-center space-x-1 cursor-pointer"
                        >
                          <span>Stream Live</span>
                          <ChevronRight className="w-3 h-3" />
                        </a>
                      )}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>

        {/* Bottom Immersive Active Audio Deck */}
        <AnimatePresence>
          {currentPlaying && (
            <motion.div 
              initial={{ y: 100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 100, opacity: 0 }}
              className="fixed bottom-6 left-6 right-6 lg:left-1/2 lg:-translate-x-1/2 lg:w-[700px] bg-brand-obsidian/90 backdrop-blur-2xl border border-white/10 rounded-3xl p-4 shadow-2xl z-50 flex flex-col md:flex-row items-center gap-4 justify-between"
            >
              {/* Audio Deck Meta */}
              <div className="flex items-center space-x-3 w-full md:w-auto">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border ${
                  currentPlaying.type === 'single' 
                    ? 'bg-orange-500/10 border-orange-500/20 text-orange-400' 
                    : 'bg-white/10 border-white/20 text-slate-300'
                }`}>
                  <Radio className={`w-5 h-5 ${isPlaying ? 'animate-spin' : ''}`} />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-white line-clamp-1 max-w-[250px]">
                    {currentPlaying.title}
                  </h4>
                  <p className="text-[10px] font-mono text-orange-450 text-orange-455 text-orange-400 tracking-wider font-semibold">
                    {currentPlaying.subtitle || 'HIS DESIRE SOUNDTRACK'}
                  </p>
                </div>
              </div>

              {/* Deck Player equalizers & controls */}
              <div className="flex items-center justify-between md:justify-center gap-6 w-full md:w-auto flex-1 px-4">
                <button
                  id="deck-play-toggle"
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="w-10 h-10 bg-white hover:bg-slate-200 rounded-full flex items-center justify-center text-slate-950 cursor-pointer"
                >
                  {isPlaying ? (
                    <Pause className="w-5 h-5 fill-current text-slate-950" />
                  ) : (
                    <Play className="w-5 h-5 fill-current text-slate-950 pl-0.5" />
                  )}
                </button>

                {/* Progress bar and time indicators */}
                <div className="flex-1 flex items-center space-x-2 text-xs font-mono text-slate-500">
                  <span>{formatTime(playbackTime)}</span>
                  <div className="flex-1 h-1 bg-white/10 rounded-sm relative overflow-hidden">
                    <div 
                      className="absolute left-0 top-0 h-full bg-gradient-to-r from-amber-500 to-amber-200 transition-all duration-100" 
                      style={{ width: `${(playbackTime / 210) * 100}%` }}
                    />
                  </div>
                  <span>3:30</span>
                </div>

                {/* Digital Equalizer Bars */}
                <div className="w-14 items-end justify-between h-5 gap-0.5 flex-shrink-0 hidden sm:flex">
                  {[...Array(6)].map((_, i) => (
                    <motion.div 
                      key={i}
                      className="w-1.5 rounded-t bg-amber-500/90"
                      animate={{ height: isPlaying ? [10, 20, 5, 24, 12, 10][(i + playbackTime) % 6] : 2 }}
                      transition={{ duration: 0.4, repeat: Infinity, repeatType: 'reverse' }}
                    />
                  ))}
                </div>
              </div>

              {/* Actions Right */}
              <div className="flex items-center space-x-4 w-full md:w-auto justify-end border-t border-white/5 md:border-t-0 pt-2 md:pt-0">
                <span className="text-[10px] font-mono text-slate-500 hidden lg:inline">
                  Streaming Virtual Deck
                </span>
                <button 
                  id="deck-close"
                  onClick={() => {
                    if (timerInterval) clearInterval(timerInterval);
                    setCurrentPlaying(null);
                    setIsPlaying(false);
                  }}
                  className="text-xs text-slate-500 hover:text-white font-mono cursor-pointer"
                >
                  Close
                </button>
              </div>

            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}
