/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface SocialLink {
  id: string;
  name: string;
  url: string;
  icon: string;
  color: string;
  category: 'music' | 'social';
}

export interface MediaItem {
  id: string;
  title: string;
  subtitle?: string;
  description?: string;
  youtubeId?: string;
  url: string;
  type: 'live' | 'single' | 'devotional' | 'video';
  tags: string[];
}

export interface ConferenceDay {
  day: string;
  title: string;
  theme: string;
  date: string;
  speakers: string[];
}
